v<h2 align="center">
    ─────「✨ ᴀsᴜ ✘ ᴍᴜsɪᴄ ✨」─────
</h2>


<h3 align="center">
 ᴛʜᴇ ᴍᴏsᴛ ғᴀsᴛ ᴀɴᴅ ᴩᴏᴡᴇʀғᴜʟ ᴍᴜsɪᴄ ᴩʟᴀʏᴇʀ ʙᴏᴛ
</h3>
<h2 align="center">
━━━━━━━━━━━━━━━━━━━━
  
##  ᴄᴀᴛᴄʜ ᴍᴇ ɪɴ [ᴛɢ🏃‍♀️](https://t.me/AbishnoiMF) 

## [ᴜᴘᴅᴀᴛᴇ](https://t.me/Abishnoi_bots)  

## ⚡ (ɢɪᴠᴇ sᴛᴀʀ)
  
━━━━━━━━━━━━━━━━━━━━
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">
  
</h2>


<p align="center">
<b>𝗗𝗘𝗣𝗟𝗢𝗬𝗠𝗘𝗡𝗧 𝗠𝗘𝗧𝗛𝗢𝗗𝗦</b>
</p>



──────────

<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʜᴇʀᴏᴋᴜ 」─
</h3>
<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/Abishnoi69/AsuXMusic"> <img src="https://img.shields.io/badge/Redirect%20To%20Heroku-black?style=for-the-badge&logo=heroku" width="200" height="35.45"/></a></p>

──────────

  
 
 
 
 
 
 
━━━━━━━━━━━━━━━━━━━━
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">
  
</h2>

<h3 align="center">
    ─「 sᴜᴩᴩᴏʀᴛ 」─
</h3>

<p align="center">
<a href="https://telegram.me/AbishnoiMF"><img src="https://img.shields.io/badge/-Support%20Group-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>
<p align="center">
<a href="https://telegram.me/Abishnoi_bots"><img src="https://img.shields.io/badge/-Support%20Channel-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>



<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">
 








<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

<h3 align="center">
    ─「 ᴄʀᴇᴅɪᴛs 」─
</h3>

: ➻

➥ [𝐀ʙɪsʜɴᴏɪ] × <a href="http://github.com/Abishnoi69/AsuXMusic" alt="Abishnoi69"> <img src="https://img.shields.io/badge/Abishnoi69-90302f?logo=github" /></a>  


- **ᴛʜᴀɴᴋꜱ ᴛᴏ [ᴛʜᴇ ᴄᴏɴᴛʀɪʙᴜᴛᴏʀs](https://github.com/Abishnoi69/AsuXMusic/graphs/contributors) ᴡʜᴏ ʜᴇʟᴩᴇᴅ ɪɴ ᴍᴀᴋɪɴɢ ᴀsᴜ ✘ ᴍᴜsɪᴄ 🖤**

----------------------------------------------------------
